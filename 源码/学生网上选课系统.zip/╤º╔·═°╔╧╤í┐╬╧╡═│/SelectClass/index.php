<?php
define('APP_NAME','App');
define('APP_PATH','./App/');
define('APP_DEBUG','true');
require './ThinkPHP/ThinkPHP.php';
?>