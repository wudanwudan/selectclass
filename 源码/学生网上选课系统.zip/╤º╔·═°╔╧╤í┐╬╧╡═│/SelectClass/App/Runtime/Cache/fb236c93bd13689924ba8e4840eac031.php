<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>教师添加课程</title>
	<link rel="stylesheet" href="../../public/css/teacher_add.css" />
</head>

<body class="all">
	<ul>
		<div class="link"><li><a href="<?php echo U('Index/index');?>">退出登录</a></li></div>
		<div class="link"><li><a href="<?php echo U('Teacher/index');?>">返回</a></li></div>
	</ul>
	<div class="B"></div>

	<form name="form1" method="post" action="<?php echo U('/Teacher/add_do');?>">
		<div class="title">编辑课程信息</div>
		<table cellspacing="0" class="table">
			<tr>
				<td class="td1">课程编号</td>
				<td class="td2"><input type="text" name="CouNo"></td>
				<td class="td1">课程名称</td>
				<td class="td2"><input type="text" name="CouName"></td>
			</tr>
			<tr>
				<td class="td1">老师工号</td>
				<td class="td2"><input type="text" name="TeaNo"></td>
				<td class="td1">老师名字</td>
				<td class="td2"><input type="text" name="TeaName"></td>
			</tr>
			<tr>
				<td class="td1">限定人数</td>
				<td class="td2"><input type="text" name="LimitNum"></td>
				<td class="td1">课程学分</td>
				<td class="td2"><input type="text" name="Credit"></td>
			</tr>
			<tr>
				<td class="td1">时间</td>
				<td class="td2"><input type="text" name="SchoolTime"></td>
				<td class="td1">地点</td>
				<td class="td2"><input type="text" name="Location"></td>
			</tr>
			<tr>
				<td class="td1">课时</td>
				<td class="td2"><input type="text" name="ClassHour"></td>
				<td class="td1">实验课时</td>
				<td class="td2"><input type="text" name="ExpHour"></td>
			</tr>
		</table>

		<div class="submit">
			<input type="submit" name="Submit" value="提交" class="button">
		</div>
	</form>

</body>
</html>