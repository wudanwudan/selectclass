<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>课程选课详情</title>
    <link rel="stylesheet" href="../../public/css/teacher_courseListDetail.css" />
</head>

<body class="all">
    <ul>
        <div class="link"><li><a href="<?php echo U('/Index/index');?>">退出登录</a></li></div>
        <div class="link"><li><a href="<?php echo U('/Teacher/coulist');?>">返回</a></li></div>
    </ul>
    <div class="B"></div>
    <table cellspacing="0" class="table">
        <tr>
            <td class="title">学号</td>
            <td class="title">姓名</td>
            <td class="title">班级编号</td>
            <td class="title">班级名称</td>
            <td class="title">性别</td>
        </tr>

        <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
            <td class="td"><?php echo ($vo["StuNo"]); ?></td>
            <td class="td"><?php echo ($vo["StuName"]); ?></td>
            <td class="td"><?php echo ($vo["ClassNo"]); ?></td>
            <td class="td"><?php echo ($vo["ClassName"]); ?></td>
            <td class="td"><?php echo ($vo["Sex"]); ?></td>
        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    </table>


</body>

</html>